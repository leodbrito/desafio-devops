- Crie uma aplicação simples em Python, que retorne “Hello World” ao receber um GET.

- Configure um nginx que sirva o retorno da aplicação ao receber um GET.
